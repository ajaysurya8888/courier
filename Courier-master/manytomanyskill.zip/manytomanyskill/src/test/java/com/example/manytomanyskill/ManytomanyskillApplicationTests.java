package com.example.manytomanyskill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytomanyskillApplicationTests {

	@Test
	void contextLoads() {
	}

}
