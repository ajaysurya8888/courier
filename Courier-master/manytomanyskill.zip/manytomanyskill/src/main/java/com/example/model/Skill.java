package com.example.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="skill")
public class Skill {
	@Column(name="skill_id")
	private String id;
	@Column(name="skill_name")
private String name;
	 @ManyToMany(mappedBy = "skillList")
private Set<Employee> employeeList; 

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Set<Employee> getEmployeeList() {
	return employeeList;
}
public void setEmployeeList(Set<Employee> employeeList) {
	this.employeeList = employeeList;
}
}
