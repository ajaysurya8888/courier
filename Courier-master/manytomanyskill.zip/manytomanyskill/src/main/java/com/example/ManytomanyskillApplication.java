package com.example;

import java.util.Date;

//import org.hibernate.mapping.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import java.util.Set;
//import com.example.model.Department;
import com.example.model.Employee;
import com.example.model.Skill;
import com.example.service.EmployeeService;
import com.example.service.SkillService;

@SpringBootApplication
public class ManytomanyskillApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(ManytomanyskillApplication.class);
	private static EmployeeService employeeService;
	private static SkillService skillService;
	
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(ManytomanyskillApplication.class, args);

		employeeService = context.getBean(EmployeeService.class);
		skillService=context.getBean(SkillService.class);
		testGetSkill();
		testAddSkill();
		
		LOGGER.info("Inside main");
	}
	 private static void testGetSkill() {

		 LOGGER.info("Start");

		Employee empl=employeeService.get("101"); 
		

		 LOGGER.debug("Employee:{}", empl);

		 LOGGER.debug("Skill List:{}", empl.getSkillList());

		 LOGGER.info("End");

		 }
private static void testAddSkill()
{
	Employee empl=employeeService.get("102"); 
	LOGGER.debug("Employee:{}", empl);
	LOGGER.debug("Before Added Skill:{}", empl.getSkillList());
	Skill skill=skillService.get("24");
Set<Skill> ski;ski=empl.getSkillList();
ski.add(skill);
empl.setSkillList(ski);
	
	
	employeeService.save(empl);
	LOGGER.debug("Employee:{}", empl);
	LOGGER.debug("After Added Skill:{}", empl.getSkillList());
}


}
