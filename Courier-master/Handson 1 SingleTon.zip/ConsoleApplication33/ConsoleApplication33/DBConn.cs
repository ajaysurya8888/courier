﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication33
{
    class DBConn
    {
        private static DBConn instance = new DBConn();
        private DBConn() { }
        public static DBConn getInstance()
        {
            return instance;
        }
        public void showmsg()
        {
            Console.WriteLine("Hi! This is singleton");
            Console.Read();
        }
    }
}
