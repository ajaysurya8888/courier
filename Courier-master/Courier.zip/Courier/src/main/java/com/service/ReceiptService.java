package com.service;
import org.springframework.stereotype.Component;

import com.dao.RegisterDAOImpl;
import com.model.PackageModel;

@Component
public class ReceiptService {
                public double calculateBill(PackageModel pack)
                {
                    RegisterDAOImpl reg=new RegisterDAOImpl();
                    
                    
                    double parcelcost=reg.calculate(pack);
                    return parcelcost;

                }

}
