package com.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class CourierModel {
	
	@NotEmpty(message="Select a role")
	private String role;
	
	@NotBlank(message="Username cannot be empty")
	private String userName;
	
	@NotBlank(message="Password cannot be empty")
	@Size(min=8,message="Password must be of length 8")
	private String password;
	
	@NotBlank(message="First Name cannot be empty")
	private String firstName;
	
	@NotBlank(message="Last Name cannot be empty")
	private String lastName;
	
	@NotBlank(message="Email Id cannot be empty")
	private String emailId;
	
	@NotBlank(message="Phone Number cannot be empty")
	private String phno;
	
	@NotEmpty(message="Gender cannot be empty")
	private String gender;
	
	private String secretQuestion,SecretAnswer;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getSecretAnswer() {
		return SecretAnswer;
	}

	public void setSecretAnswer(String secretAnswer) {
		SecretAnswer = secretAnswer;
	}

}
