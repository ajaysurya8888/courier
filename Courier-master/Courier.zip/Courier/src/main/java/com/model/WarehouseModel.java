package com.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class WarehouseModel {
@NotNull(message="Branch id cannot be empty")
@Min(1)
private int branchId;
@NotBlank(message="BranchName cannot be empty")
private String branchName;
@NotBlank(message="Branch Location cannot be empty")
private String branchLocation;
@NotBlank(message="Contact Number cannot be empty")
@Size(min=10,message="Contact number should be of length 10")
private String contactNumber;
public int getBranchId() {
       return branchId;
}
public void setBranchId(int branchId) {
       this.branchId = branchId;
}
public String getBranchName() {
       return branchName;
}
public void setBranchName(String branchName) {
       this.branchName = branchName;
}
public String getBranchLocation() {
       return branchLocation;
}
public void setBranchLocation(String branchLocation) {
       this.branchLocation = branchLocation;
}
public String getContactNumber() {
       return contactNumber;
}
public void setContactNumber(String contactNumber) {
       this.contactNumber = contactNumber;
}

}
